import numpy as np
import pandas as pd
import rdkit
import rdkit.Chem as Chem
from rdkit.Chem import AllChem
from rdkit.Chem import EnumerateStereoisomers
import networkx as nx

import torch
import os
import json
import csv
from pathlib import Path
from tqdm import tqdm
from torch_geometric.loader import DataLoader
from vocabulary_builders import WordVocab
from utilss import *

from molecular_interactions import MolecularInteractionDataset
from sklearn.model_selection import KFold
from interaction_networks import *
from graphmakers import *

from torch import nn as nn

# Set environment variable to avoid memory fragmentation
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'expandable_segments:True'

# Set CUDA visible device to GPU 1


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
LR = 1e-4
NUM_EPOCHS = 300
seed = 42
seed_torch(seed)
dataset__name = 'davis'  # dataset name
batch_size = 128  # Four active GNN branches need more GPU memory.

# Set PROJECT_DIR to the directory containing the input data and output folders.
# The default is the directory containing this script; override it with an
# environment variable when your data is stored elsewhere.
PROJECT_DIR = Path(os.environ.get('PROJECT_DIR', Path(__file__).resolve().parent))

# Data preprocessing part
dataset_name = PROJECT_DIR / f'{dataset__name}_processeds.csv'
esm2_csv = PROJECT_DIR / f'{dataset__name}_esm2_embeddings.csv'
df = pd.read_csv(dataset_name)

smiles = set(df['compound_iso_smiles'])
target = set(df['target_key'])

target_seq = {}
for i in range(len(df)):
    target_seq[df.loc[i, 'target_key']] = df.loc[i, 'target_sequence']

smiles_graph = {}
for sm in smiles:
    _, graph = build_smiles_contact_map(sm)
    smiles_graph[sm] = graph

target_uniprot_dict = {}
target_process_start = {}
target_process_end = {}

for i in range(len(df)):
    target = df.loc[i, 'target_key']

    uniprot = df.loc[i, 'target_key']

    target_uniprot_dict[target] = uniprot
    target_process_start[target] = df.loc[i, 'target_sequence_start']
    target_process_end[target] = df.loc[i, 'target_sequence_end']

if 'kiba' in dataset__name:
    contact_dir = PROJECT_DIR / 'kibas_npy_contact_maps'
elif 'davis' in dataset__name:
    contact_dir = PROJECT_DIR / 'davis_npy_contact_maps'
else:
    raise ValueError("Unsupported dataset. Please check the dataset name.")

target_graph = {}

for target in tqdm(target_seq.keys()):
    uniprot = target_uniprot_dict[target]
    contact_path = os.path.join(contact_dir, uniprot + '.npy')
    if not os.path.exists(contact_path):
        raise FileNotFoundError(f"Contact map file {contact_path} not found. Please ensure all contact maps are generated.")
    contact_map = np.load(contact_path)
    start = target_process_start[target]
    end = target_process_end[target]
    _, graph = build_protein_contact_map(uniprot, target_seq[target], contact_dir, start, end)
    target_graph[target] = graph

# Load vocabulary
drug_vocab = WordVocab.load_vocab(PROJECT_DIR / 'Vocab' / 'smiles_vocab.pkl')

# Build molecule features
tar_len = 1000
seq_len = 540

smiles_idx = {}
smiles_emb = {}
smiles_len = {}
for sm in smiles:
    content = []
    flag = 0
    for i in range(len(sm)):
        if flag >= len(sm):
            break
        if (flag + 1 < len(sm)):
            if drug_vocab.stoi.__contains__(sm[flag:flag + 2]):
                content.append(drug_vocab.stoi.get(sm[flag:flag + 2]))
                flag = flag + 2
                continue
        content.append(drug_vocab.stoi.get(sm[flag], drug_vocab.unk_index))
        flag = flag + 1

    if len(content) > seq_len:
        content = content[:seq_len]

    X = [drug_vocab.sos_index] + content + [drug_vocab.eos_index]
    smiles_len[sm] = len(content)
    if seq_len > len(X):
        padding = [drug_vocab.pad_index] * (seq_len - len(X))
        X.extend(padding)

    smiles_emb[sm] = torch.tensor(X)

    if not smiles_idx.__contains__(sm):
        tem = []
        for i, c in enumerate(X):
            if atom_dict.__contains__(c):
                tem.append(i)
        smiles_idx[sm] = tem

# Load all eleven ESM-2 vectors for each target from the generated CSV.
esm2_df = pd.read_csv(esm2_csv, dtype={'target_key': str})
target_emb = {}
target_len = {}
for target_id, sequence in target_seq.items():
    group = esm2_df.loc[esm2_df['target_key'] == str(target_id)].sort_values('variant_index')
    if group['variant_index'].tolist() != list(range(11)):
        raise ValueError(f'Missing ESM-2 vectors 0..10 for target {target_id}')
    vectors = np.asarray([json.loads(value) for value in group['esm2_embedding']], dtype=np.float32)
    if vectors.shape != (11, 1280) or not np.isfinite(vectors).all():
        raise ValueError(f'Invalid ESM-2 vectors for target {target_id}: {vectors.shape}')
    target_emb[str(target_id)] = torch.from_numpy(vectors)
    target_len[sequence] = len(sequence)  # Used for graph construction.
# Build dataset
print("Building dataset...")
dataset = MolecularInteractionDataset(root=str(PROJECT_DIR),
                                      path=dataset_name, 
                                      smiles_emb=smiles_emb, 
                                      target_emb=target_emb, 
                                      smiles_idx=smiles_idx, 
                                      smiles_graph=smiles_graph, 
                                      target_graph=target_graph, 
                                      smiles_len=smiles_len, 
                                      target_len=target_len,
                                      target_seq=target_seq)

# Model training preparation
model_name = 'default'
model_file_name = str(PROJECT_DIR / 'Model' / f'{dataset__name}_{model_name}.pt')
os.makedirs(os.path.dirname(model_file_name), exist_ok=True)

num_folds = 5
kf = KFold(n_splits=num_folds, shuffle=True, random_state=0)

# Model training and evaluation
for fold, (train_indices, test_indices) in enumerate(kf.split(dataset)):
    print(f"Fold {fold+1}")
    # Keep each fold's checkpoint separate so the final fold cannot overwrite
    # the models from earlier folds.
    fold_model_file_name = model_file_name.replace('.pt', f'_fold{fold + 1}.pt')
    validation_metrics_file = fold_model_file_name.replace('.pt', '_validation_metrics.csv')
    metric_names = ['CI', 'MSE', 'RMSE', 'Pearson', 'Spearman',
                    'MAE', 'ExplainedVariance', 'RM2', 'RM', 'R2']
    with open(validation_metrics_file, 'w', newline='') as metrics_file:
        csv.writer(metrics_file).writerow(['fold', 'epoch', 'learning_rate', *metric_names])
    
    model = CrossModalInteractionNet(embedding_dim=1280, 
                                     lstm_dim=256, 
                                     hidden_dim=512, 
                                     dropout_rate=0.3,
                                     alpha=0.2, 
                                     n_heads=16, 
                                     bilstm_layers=3, 
                                     protein_vocab=26,
                                     smile_vocab=45, 
                                     theta=0.5,
                                     target_seq=target_seq,    
                                     smiles_emb=smiles_emb,                                     
                                     target_emb=target_emb,
                                     smiles_len=smiles_len,
                                     target_len=target_len,
                                     smiles_idx=smiles_idx,
                                     smiles_graph=smiles_graph,
                                     target_graph=target_graph).to(device)
    
    optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5, weight_decay=1e-5)
    # Decay from the initial learning rate to a lower floor over the full run.
    schedule = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=NUM_EPOCHS, eta_min=1e-6
    )
    
    best_mse = 1000
    best_test_mse = 1000
    best_epoch = -1
    best_test_epoch = -1

    for epoch in range(NUM_EPOCHS):
        print("No {} epoch".format(epoch))
        
        if epoch == 0:
            val_size = int(len(dataset) * 0.1)
            train_dataset = torch.utils.data.Subset(dataset, train_indices)
            train_dataset, val_dataset = torch.utils.data.random_split(
                dataset=train_dataset,
                lengths=[len(train_dataset)-val_size, val_size],
                generator=torch.Generator().manual_seed(0)
            )
            test_dataset = torch.utils.data.Subset(dataset, test_indices)
            
            train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, pin_memory=True)
            val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, pin_memory=True)
            test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, pin_memory=True)
        
        train(model, train_loader, optimizer, epoch)
        G, P = predicting(model, val_loader)
        metrics = calculate_metrics_and_return(
            G, P, f'validation fold {fold + 1}, epoch {epoch + 1}'
        )
        val1 = metrics[1]
        with open(validation_metrics_file, 'a', newline='') as metrics_file:
            csv.writer(metrics_file).writerow([
                fold + 1, epoch + 1, optimizer.param_groups[0]['lr'], *metrics
            ])
        
        if val1 < best_mse:
            best_mse = val1
            best_epoch = epoch + 1
            if fold_model_file_name is not None:
                torch.save(model.state_dict(), fold_model_file_name)
            print('mse improved at epoch ', best_epoch, '; best_mse', best_mse)
        else:
            print('current mse: ', val1, ' No improvement since epoch ', best_epoch, '; best_mse', best_mse)
        
        schedule.step()
    
    print(fold_model_file_name)
    save_model = torch.load(fold_model_file_name, map_location=device)
    model_dict = model.state_dict()
    state_dict = {k:v for k,v in save_model.items() if k in model_dict.keys()}
    model_dict.update(state_dict)
    model.load_state_dict(model_dict)
    
    G, P = predicting(model, test_loader)
    cindex, mse, rmse, pearson, spearman, mae, ev, rm2, rm, r2 = calculate_metrics_and_return(G, P, test_loader.dataset)
    print(f"Test metrics - CI: {cindex}, MSE: {mse}, RMSE: {rmse}, Pearson: {pearson}, Spearman: {spearman}, MAE: {mae}, EV: {ev}, R2: {r2}, RM: {rm}, RM2: {rm2}")
