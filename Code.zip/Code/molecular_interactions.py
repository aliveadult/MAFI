"""Interaction rows for the original sequence model plus the graph branches.

Graph node features and edges are cached by CrossModalInteractionNet. Keeping
only pair identifiers here avoids the invalid node/edge alignment in the old
per-row combined graphs and saves a large amount of preprocessing time.
"""
import pandas as pd
from torch.utils.data import Dataset
from torch_geometric.data import Data
import torch


class MolecularInteractionDataset(Dataset):
    def __init__(self, root, path, smiles_emb, target_emb, smiles_idx,
                 smiles_graph, target_graph, smiles_len, target_len, target_seq):
        self.frame = pd.read_csv(path, dtype={"target_key": str}).reset_index(drop=True)
        required = {"compound_iso_smiles", "target_key", "affinity"}
        if not required.issubset(self.frame.columns):
            raise ValueError(f"Interaction CSV requires {sorted(required)}")
        missing = set(self.frame["target_key"]) - set(target_emb)
        if missing:
            raise ValueError(f"Missing ESM-2 embedding for target: {next(iter(missing))}")

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, index):
        row = self.frame.iloc[index]
        return Data(
            y=torch.tensor([float(row["affinity"])], dtype=torch.float32),
            sm=str(row["compound_iso_smiles"]),
            target=str(row["target_key"]),
        )
